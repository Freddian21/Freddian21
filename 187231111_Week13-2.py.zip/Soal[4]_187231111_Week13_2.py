def primeFactor (n) : 
    # Search factor
    prime = 0
    for i in range (1,n+1):
        if n % i == 0 :
            prime = i
            #Seacrh Prime
            flag = 0 
            for j in range (1,prime+1) :
                if prime % j == 0 :
                    flag += 1
                    
            if flag == 2 : 
                print(prime, end= " ")
            

n = int(input("input number : "))
primeFactor(n)