def smallComFactor(n, k):
    result = 0
    i = 2
    while result == 0:
        if n % i == 0 and k % i == 0:
            result = i
        i += 1
    return result


n = int(input("input n : "))
k = int(input("input k : "))
print(smallComFactor(n, k))


