def numOfUniqDigit(n):
    result = 0
    frekuensi = [0 for i in range(10)]

    while n > 0:
        digit = n % 10
        if frekuensi[digit] == 0:
            result += 1
        frekuensi[digit] += 1
        n //= 10
    
    return result


n = int(input("Masukkan angka: "))
print(numOfUniqDigit(n))


