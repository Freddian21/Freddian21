
def sameFactor(n,k) : 
    for i in range(2, n+1):
        if (n % i == 0 and k % i == 0 and i!= n and i!= k):
            print(i, end=" ")


n = int(input("input nilai n : "))
k = int(input("input nilai k : "))
sameFactor(n,k)
