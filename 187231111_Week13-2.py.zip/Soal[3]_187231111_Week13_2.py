def dispFirstPrime(n):
    count = 0
    num = 2

    while count < n:
        prime = True
        flag = 0
        for i in range(1, num + 1):
            if num % i == 0:
                flag += 1

        if flag != 2:
            prime = False

        if prime:
            print(num, end=" ")
            count += 1

        num += 1


n = int(input("input number: "))
dispFirstPrime(n)
