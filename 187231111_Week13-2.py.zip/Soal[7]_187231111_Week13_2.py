def numOfDigit(n):
    count = 0
    while n > 0 : 
        n = n // 10
        count +=1
    
    print("jumlah bilangan adalah : ", count)
    

n = int(input("input number : "))
numOfDigit(n)
