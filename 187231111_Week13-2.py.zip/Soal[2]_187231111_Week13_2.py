def dispPrime(n) :
    for i in range (1,n+1) :
        flag = 0
        for j in range (1,n+1) :
            if i % j == 0 :
                flag += 1
        
        if flag == 2 : 
            print (i , end= " ")
                


n = int(input("input number : "))
dispPrime(n)
    
    
    
    
    




