def prime (n) : 
    flag = 0
    for i in range (1,n+1):
        if n % i == 0:
            flag += 1
            
    if flag == 2:
        print("True, bilangan adalah Prima")
    else:
        print("False, bilangan bukan merupakan bilangan prima")


n = int(input("Input number : "))
prime(n)
